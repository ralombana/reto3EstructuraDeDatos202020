package test.logic;

import static org.junit.Assert.*;
import model.logic.Modelo;

import org.junit.Before;
import org.junit.Test;

public class TestModelo {
	
	private Modelo model;
	private static int CAPACIDAD=100;
	
	@Before
	public void setUp1() {
		model= new Modelo(CAPACIDAD);
	}

	public void setUp2() {
		for(int i =0; i< CAPACIDAD;i++){
			model.agregar(""+i);
		}
	}

	@Test
	public void testModelo() {
		assertTrue(model!=null);
		assertEquals(0, model.darTamano());  // Modelo con 0 elementos presentes.
	}

	@Test
	public void testDarTamano() {
		// TODO
		setUp2();
		assertEquals(100, model.darTamano());
	}

	@Test
	public void testAgregar() {
		// TODO Completar la prueba
		Modelo add =new Modelo();
		
		model.agregar(null);
		assertEquals(1, model.darTamano());
	}

	@Test
	public void testBuscar() {
		setUp2();
		// TODO Completar la prueba
		Modelo buscar= new Modelo();
		setObjectId("Id1");
		model.agregar();
		assertNotNull(model.buscar());
		
	Modelo x = new Modelo();
		x.setObjectId("Id1");
		model.agregar(x);
		assertNotNull(model.buscarPeliculasBuenas(director));
	}

	@Test
	public void testEliminar() {
		setUp2();
		// TODO Completar la prueba
		return;
		
	}
	
	@Test 
	public void testBuscarPeliculaBuena()
	{
		String x=new String();
		
		model.buscarPeliculasBuenas(x);
		assertNotNull(model.buscarPeliculasBuenas(x));
		
	}
	

}
